include("src/FastUnitaryEigenvalues.jl")
using LinearAlgebra
global FUE = Main.FastUnitaryEigenvalues

println(FUE.greet_your_package_name())

global A = FUE.naive_unitary(4)

display(round.(A, digits=2))
display(round.(A*A', digits=2))

global B = FUE.naive_uuh(4)
display(round.(B, digits=2))
display(round.(B*B', digits=2))

global C = FUE.CoreTransformation(-1im, 0, 2)
display(C)

global S = I(3) .+ 0im
FUE.apply(C,S)
display(FUE.apply(C, S))
FUE.apply!(C, S)
display(S)

# Display
FUE.display_ct(C)

# Set diagonal
global C1 = FUE.CoreTransformation(-1im, eps(Float64)*im, 3)
FUE.display_ct(C1)
FUE.display_ct(FUE.set_diagonal(C1))

global C2 = FUE.CoreTransformation(1/sqrt(2)+0im, -1/sqrt(2)+0im)
