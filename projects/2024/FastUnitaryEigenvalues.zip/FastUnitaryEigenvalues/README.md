# FastUnitaryEigenvalues

[![Build Status](https://github.com/Westnickp/FastUnitaryEigenvalues.jl/actions/workflows/CI.yml/badge.svg?branch=main)](https://github.com/Westnickp/FastUnitaryEigenvalues.jl/actions/workflows/CI.yml?query=branch%3Amain)
