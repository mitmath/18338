using LinearAlgebra
include("../src/MultivariateLanczos.jl")

k = 2;
n = 100;
m = 2;
b = ones(n)
trials = 10

for i=1:trials

    mats = [randn(n,n) for i=1:k]
    # mats = [mat' * mat for mat in mats]
    A = [diagm(eigvals(a)) for a in mats]
    (T,Q) = MultivariateLanczos(A,b,m);
    println(Q[(2,0)])
end