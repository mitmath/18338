using Test

include("../src/MultivariateLanczos.jl")

include("test_multivarLanczos.jl")